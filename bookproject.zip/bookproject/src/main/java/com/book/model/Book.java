package com.book.model;

import javax.persistence.*;

@Entity
@Table(name = "Book")
public class Book {
    private int id;
    private String bookname;
    private String author;
    private String publisher;

    public Book() {
    }

    public Book(int id, String bookname, String author, String publisher) {
        this.id = id;
        this.bookname = bookname;
        this.author = author;
        this.publisher = publisher;
    }

    @Id
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getBookname() {
        return bookname;
    }

    public void setBookname(String bookname) {
        this.bookname = bookname;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }
}
